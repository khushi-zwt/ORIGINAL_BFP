<?php
/**
* Default site header.
*/

if ( !defined( 'ABSPATH' ) || !function_exists( 'add_filter' ) ) {
	header( 'Status: 403 Forbidden' );
	header( 'HTTP/1.1 403 Forbidden' );
	exit;
}
?>
<!DOCTYPE html>
<html <?php language_attributes() ?> class="no-js">
<head>
	<meta charset="<?php bloginfo( 'charset' ) ?>" />
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" />
    <meta name="description" content="" />
    <meta name="keywords" content="" >
	<meta name="SKYPE_TOOLBAR" content="SKYPE_TOOLBAR_PARSER_COMPATIBLE" />
    <!-- <meta name="theme-color" content="#7b0a2e"/> -->
	<link rel="profile" href="http://gmpg.org/xfn/11" />
	<link rel="pingback" href="<?php bloginfo( 'pingback_url' ) ?>" />


	<?php wp_head(); ?>
</head>
<body <?php body_class() ?>>
	<?php
	echo '<!-- start -->
	<div class="wrapper">
		<div class="main-container">
		<!-- device menu -->
			<div class="mbnav">
                <div class="mbnav__backdrop"></div>
                <div class="mbnav__state" data-clickable="true">
                    <!--  main responsive menu -->
                    <div class="mbnav__inner">
						<div class="content-wrap d-md-none d-flex">
							<div class="main-social-icon-wrapper">';
									if(have_rows( 'social_icons','option' )) {
										$telephone   	= get_field('telephone','option');
										$head_tel_phone = preg_replace( '/[^\d+]/', '', $telephone );
										echo '<div class="social-media">' ;
											while( have_rows( 'social_icons','option' )) {
												the_row();
												$social_icon = get_sub_field( 'icon', 'option' );
												$social_link = get_sub_field('social_icon_link', 'option');
		
												if( $social_icon == 'instagram') {
													echo '<a href="' . $social_link . '" target="_blank"><img src="' . get_template_directory_uri() . '/assets/images/instagram.svg" alt="instagram" /></a>' ;
												}
												if( $social_icon == 'facebook') {
													echo '<a href="' . $social_link . '" target="_blank"><img src="' . get_template_directory_uri() . '/assets/images/facebook.svg" alt="facebook" /></a>' ;
												}
											}
										echo '</div>
										<div class="telephone-number"><a href="tel:'.$head_tel_phone.'">'.$telephone.'</a></div>
										';
									}
								echo'</div>
							</div>';

						if ( has_nav_menu( 'header_menu' ) ) {
							$header_menu = array(
								'theme_location'  => 'header_menu',
								'container'       => 'ul',
								'container_class' => 'header_menu',
							);
							wp_nav_menu($header_menu);
						}
                    echo'</div>
                </div>
            </div>';
            $brand_logo  = get_field( 'brand_logo','option' );
			$telephone   = get_field('telephone','option');
			$tel_phone 	 = preg_replace( '/[^\d+]/', '', $telephone );
			$menu_icon   = get_field('menu_icon','option');
			
				echo'<header class="main-header py-30">
						<div class="d-flex justify-content-between align-items-start">';
							
							if($brand_logo){
								echo'<div class="main-social-icon-wrapper d-md-flex d-none">';
									if(have_rows( 'social_icons','option' )) {
										echo '<div class="social-media">' ;
											while( have_rows( 'social_icons','option' )) {
												the_row();
												$social_icon = get_sub_field( 'icon', 'option' );
												$social_link = get_sub_field('social_icon_link', 'option');
		
												if( $social_icon == 'instagram') {
													echo '<a href="' . $social_link . '" target="_blank"><img src="' . get_template_directory_uri() . '/assets/images/instagram.svg" alt="instagram" /></a>' ;
												}
												if( $social_icon == 'facebook') {
													echo '<a href="' . $social_link . '" target="_blank"><img src="' . get_template_directory_uri() . '/assets/images/facebook.svg" alt="facebook" /></a>' ;
												}
											}
										echo '</div>';
									}
								echo'</div>
								
									<a href="'.home_url( '/' ).'" class="brand">
										<img src="'.$brand_logo['url'].'" alt="'.get_bloginfo('name').'">
									</a>
								<div class="hamburger-wrapper">
									<div class="right-head d-flex align-items-center ">
										<div class="telephone-number d-none d-md-block"><a href="tel:'.$tel_phone.'">'.$telephone.'</a></div>
										<div class="right-image hamburger"><img src="'.get_template_directory_uri().'/assets/images/header-menu-icon.svg" alt="menu-icon"></div>
									</div>
								</div>';
							}
							echo'
						</div>
				</header>';

				if ( !is_home() && ! is_front_page() && ! is_404() ){
				global $post;
				$banner_image		= get_field('banner_image', $post->ID);
					if($banner_image){
					echo'<section class="banner-section inner-banner-header">
							<div class="main-banner">
								<div class="banner-background-image" style="background:url('. $banner_image['url']. ') center center; background-size: cover; background-repeat: no-repeat;"></div>
								<div class="container">
									<div class="banner-inner">
										<div class="home-banner-text"><h1 class="h1">'
											.get_the_title().'</h1>
										</div>
									</div>
								</div>
							</div>
						</section>';
						if(! is_search()){
							echo '<div class="blank_div"></div>';
						}
					}
				}
