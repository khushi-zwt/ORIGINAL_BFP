<?php
/**
 * Post template.
 */
if (!defined('ABSPATH') || !function_exists('add_filter')) {
	header('Status: 403 Forbidden');
	header('HTTP/1.1 403 Forbidden');
	exit;
}
get_header();

$featured_img_url 	= get_the_post_thumbnail_url(get_the_ID(),'full');
$beach_left_image	= get_field('beach_left_image');
$location_title 	= get_field('location_title');
$location_subtitle 	= get_field('location_subtitle');
$location_content 	= get_field('location_content');
$timings 			= get_field('timings');
$address 			= get_field('address');
$phone   			= get_field('phone');
$tel_phone 			= preg_replace( '/[^\d+]/', '', $phone );
$location_link 		= get_field('location_link');

if(isset($beach_left_image) && !empty($beach_left_image)){
	$left_img = $beach_left_image;
}else{
	$left_img = $featured_img_url;
}

?>

<section class="two-col-block location-post-content" style="background:url(<?php echo get_template_directory_uri() .'/assets/images/bg_image.jpg' ?>) center center; background-size: cover; background-repeat: no-repeat;">
<div class="two-col-wrapper row no-gutters left">
		<div class="left-col cell-md-6">
			<img src="<?php echo $left_img; ?>">
		</div>
		<div class="right-col cell-md-6">
			<div class="inner-right-part">

				<?php if($location_title){ ?>
					<div class="main-title">
						<div class="inner-content"><h2 class="h2"><?php echo $location_title; ?></h2></div>
					</div>
				<?php } ?>
				<?php if($location_subtitle || $location_content) { ?>
					<div class="subtitle">
						<div class="inner-content">
							<?php if($location_subtitle){?><p><?php echo $location_subtitle; ?></p><?php }?>
						</div>
						<?php if($location_content){ echo $location_content; ?><?php } ?>
					</div>

					<?php if($timings){ ?>
						<div class="content">
							<div class="inner-content">
								<p><?php echo $timings; ?></p>
							</div>
						</div>
						<hr>
					<?php } ?>
					
					<?php if($address){ ?>
						<div class="content">
							<div class="inner-content">
								<p><?php echo $address; ?></p>
							</div>
						</div>
						<hr>
					<?php } ?>

					<?php if($phone){ ?>
						<div class="content">
							<div class="inner-content">
								<a href="tel: <?php echo $tel_phone; ?>"><?php echo $phone; ?></a>
							</div>
						</div>
					<?php } ?>

					<?php if($location_link){ ?>
						<div class="d-block see-menu-btn">
							<a href="<?php echo $location_link; ?>" class="btn button" target="_blank"><?php echo __('Get Directions'); ?></a>
						</div>
					<?php }
				}
				?>
			</div>
		</div>
	</div>
</section>
<?php
include get_theme_file_path( '/template-part/components.php' );
get_footer();
