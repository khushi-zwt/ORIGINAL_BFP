<?php
$location_title   = get_sub_field('location_title');   //title
$location         = get_sub_field('location');         //realtionship field
$see_our_location = get_sub_field('see_our_location'); //button

global $post;
if(is_singular('location')){
	$post_id = get_the_ID();
	foreach($location as $k => $value){
		if($value == $post_id){
		  unset($location[$k]);
		}
	}
}

$location_qry = array(
	'post_type' => 'location',
	'post__in' 	=> $location,
	'orderby'   => 'post__in',
);

$the_query_location = new WP_Query( $location_qry );
?>

<?php
if($the_query_location->have_posts()) { ?>
	<section class="location-wrapper" style="background:url(<?php echo get_template_directory_uri() .'/assets/images/bg_image.jpg' ?>) center center; background-size: cover; background-repeat: no-repeat;">
		<?php
			if($location_title){ ?>
				<div class="location-title h2 text-center"><?php echo $location_title ?></div>
		<?php } ?>
		<div class="d-flex gallery-wrap">
			<?php while($the_query_location->have_posts()) { $the_query_location->the_post(); 
				// if(){
				// }
				?>
				<div class="wrap-beach-dinner">
						<div class="post-title">
							<?php the_title(); ?>
						</div>
					<?php if(has_post_thumbnail()){
						{ ?>
							<div class="post-image">
								<a href="<?php echo get_the_permalink(); ?>">
									<?php $featured_img_url = get_the_post_thumbnail_url(get_the_ID(),'full'); ?>
									<img src="<?php echo $featured_img_url ?>">
								</a>
							</div>
						<?php }
					} ?>
				</div>
			<?php } wp_reset_postdata();?>
		</div>
		<div class="button-group">
			<?php if($see_our_location ){
				$see_our_location_url    = $see_our_location['url'];
				$see_our_location_title  = $see_our_location['title'];
				$see_our_location_target = $see_our_location['target'] ? $see_our_location['target'] : '_self'; ?>

				<div class="our-location-btn">
					<a class="btn" href="<?php echo esc_url($see_our_location_url ) ?>" target="<?php echo esc_attr( $see_our_location_target )?>"> <?php echo esc_html( $see_our_location_title )?> </a>
				</div>
			<?php } ?>
		</div>
	</section>
<?php } ?>
