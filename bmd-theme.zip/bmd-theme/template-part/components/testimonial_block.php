<?php
$testimonial = get_sub_field('testimonial');                   //relationship field
if( $testimonial ){ ?>
<section class="testimonial-block">
	<div class="testimonial-wrapper" style="background:url(<?php echo get_template_directory_uri() .'/assets/images/bg_image.jpg' ?>) center center; background-size: cover; background-repeat: no-repeat;">
		<div class="container">
			<div class="testimonial-inner-wrapper row no-wrap">
				<?php foreach( $testimonial as $post ){
					$testimonial_rating = get_field('testimonial_rating', $post->ID);
					$testimonial_author = get_field('testimonial_author', $post->ID);
					setup_postdata($post); ?>
					<div class="testimonial-content-wrapper cell-md-6">
						<div class="rating d-flex">
							<?php
								for( $i = 1 ; $i <= $testimonial_rating ; $i++) { ?>
									<span>
										<img src="<?php echo get_template_directory_uri() .'/assets/images/rating.svg'?>" alt="rating-icon">
									</span>
							<?php } ?>
						</div>
						<div class="testimonial-title">
							<h3 class="h3"><?php echo get_the_title(); ?></h3>
						</div>
						<div class="testimonial-content">
							<?php echo get_the_content(); ?>
						</div>
						<div class="testimonial-author">
							<p><?php echo $testimonial_author; ?></p>
							
						</div>
					</div>
				<?php } ?>
			</div>
			<?php wp_reset_postdata(); ?>
		</div>
	</div>
</section>
<?php } ?>
