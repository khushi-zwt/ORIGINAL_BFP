<?php
$images = get_sub_field('image_gallery_section');
$gallery_custom_class = get_sub_field('gallery_custom_class');
$size = 'full';
?>
<section class="gallery-block <?php echo $gallery_custom_class;?> " style="background:url(<?php echo get_template_directory_uri() .'/assets/images/bg_image.jpg' ?>) center center; background-size: cover; background-repeat: no-repeat;">
	<?php if( $images ){?>
		<div class="photo-gallery">
			<div class="row no-gutters">
				<?php foreach( $images as $image ) { ?>
					<div class="cell-md-3 cell-sm-6">
						<div class="image-block">
							<a href="<?php echo esc_url($image['url']); ?>" data-fancybox="gallery">
								<img src="<?php echo esc_url($image['url']); ?>" alt="<?php echo esc_attr($image['alt']); ?>" />
							</a>
						</div>
					</div>
				<?php } ?>
			</div>
		</div>
	<?php } ?>
</section>

