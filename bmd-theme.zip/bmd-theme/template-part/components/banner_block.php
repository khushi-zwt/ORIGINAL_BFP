<?php

$home_banner_background_image = get_sub_field('home_banner_background_image');
$home_banner_text             = get_sub_field('home_banner_text');
$see_our_menu_link            = get_sub_field('see_our_menu_link');
$order_online_link            = get_sub_field('order_online_link');
$scroll_down_cta              = get_sub_field('scroll_down_cta');


if($home_banner_background_image || $home_banner_text){
echo'<section class="banner-section">
		<div class="main-banner">
			<div class="banner-background-image">'.wp_get_attachment_image($home_banner_background_image,'full').'</div>
			<div class="container">
				<div class="banner-inner">
					<div class="home-banner-text"><h1 class="h1">'
						.$home_banner_text.'</h1>
					</div>
					<div class="button-group">';
						if($see_our_menu_link || $order_online_link){

							$link_url    = $see_our_menu_link['url'];
							$link_title  = $see_our_menu_link['title'];
							$link_target = $see_our_menu_link['target'] ? $see_our_menu_link['target'] : '_self';

							echo'<div class="see-menu-btn"><a  class="btn" href="'. esc_url( $link_url ) .'" target="'. esc_attr( $link_target ).'">'. esc_html( $link_title ).'</a></div>';

							$order_online_link_url    = $order_online_link['url'];
							$order_online_link_title  = $order_online_link['title'];
							$order_online_link_target = $order_online_link['target'] ? $order_online_link['target'] : '_self';

							echo'<div class="order-btn"><a  class="btn" href="'. esc_url( $order_online_link_url ) .'" target="'. esc_attr( $order_online_link_target ).'">'. esc_html( $order_online_link_title ).'</a></div>';
						}
					echo '</div>';
					if($scroll_down_cta){
						echo '<div class="scroll-down">
								<div class="next-scroll">Scroll</div>
						</div>';
					}
				echo'</div>
			</div>
		</div>
	</section>
';
}
echo'<div class="blank_div"></div>';
