<?php
if(have_rows('menu')){?>
	<section class="menu-section" style="background-image: url('<?php echo get_template_directory_uri(); ?>/assets/images/menu-bg.png');">
		<div class="main-menu-wrapper">
			<div class="container-fluid">
				<?php while(have_rows('menu')){the_row();
					$menu_title     = get_sub_field('menu_title');
					$top_tagline    = get_sub_field('top_tagline');
					$bottom_tagline = get_sub_field('bottom_tagline'); ?>
						<div class="menu-inner-wrapper">
							<div class="menu-title-wrapper">
								<div class="menu-title">
									<?php echo $menu_title ?>
								</div>
							</div>
							<div class="top-tagline">
								<?php echo $top_tagline ?>
							</div>
							<?php
								if(have_rows('menu_items')){
									echo '<div class="menu-items-wrapper">';
										while(have_rows('menu_items')){ the_row();
											$food_title   = get_sub_field('food_title');
											$ingredients  = get_sub_field('ingredients');
											$price        = get_sub_field('price');?>
												<div class="menu-items">
													<div class="menu-title-price">
														<div class="food-title"><?php echo $food_title ?></div>
														<div class="dotted-line"></div>
														<div class="food-price"><?php echo $price ?></div>
													</div>
													<?php if($ingredients){?>
														<div class="ingredients"><?php echo $ingredients ?></div>
													<?php } ?>
												</div>
										<?php	}
									echo '</div>';
								} ?>
								<div class="bottom-tagline">
									<?php echo $bottom_tagline ?>
								</div>
						</div>
				<?php } ?>
			</div>
		</div>
	</section>
<?php } ?>
