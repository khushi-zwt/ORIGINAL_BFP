<?php
$featured_posts = get_sub_field('location_list');
if( $featured_posts ) {?>
<section class="two-col-block contact-column-block" style="background:url(<?php echo get_template_directory_uri() .'/assets/images/bg_image.jpg' ?>) center center; background-size: cover; background-repeat: no-repeat;">
	<?php foreach( $featured_posts as $location ) {
		$location_subtitle 	= get_field('location_subtitle', $location->ID);
		$location_content 	= get_field('location_content', $location->ID);

		$timings 			= get_field('timings', $location->ID);
		$address 			= get_field('address', $location->ID);
		$phone   			= get_field('phone', $location->ID);
		$tel_phone 			= preg_replace( '/[^\d+]/', '', $phone );

		$featured_img_url = get_the_post_thumbnail_url($location->ID);
			if(!$featured_img_url ){
				$cls = ' cell-md-12 ';
			}
			else{
				$cls=' justify-content-center ';
			}
	?>
	<div class="location-list-wrapper two-col-wrapper row no-gutters <?php echo $cls; ?> ">
		<div class="left-col cell-md-6">
			<img src="<?php echo $featured_img_url ?>">
		</div>
		<div class="right-col <?php echo $cls; ?> cell-md-6">
			<div class="inner-right-part">
				<div class="main-title">
					<div class="inner-content">
						<a href="<?php echo get_the_permalink($location->ID); ?>"><h2 class="h2"><?php echo get_the_title($location->ID); ?></h2></a>
					</div>
				</div>
				<div class="subtitle">
					<div class="inner-content">
						<?php if($location_content){ ?>
							<?php echo $location_content; ?>
						<?php } ?>
					</div>
				</div>

				<?php if($timings){ ?>
					<div class="content">
						<div class="inner-content">
							<p><?php echo get_field( 'timings', $location->ID ); ?></p>
						</div>
					</div>
					<hr>
				<?php } ?>

				<?php if($address){ ?>
					<div class="content">
						<div class="inner-content">
							<p><?php echo get_field( 'address', $location->ID ); ?></p>
						</div>
					</div>
					<hr>
				<?php } ?>

				<?php if($phone){ ?>
					<div class="content">
						<div class="inner-content see-menu-btn">
							<a href="tel: <?php echo $tel_phone; ?>"><?php echo $phone; ?></a>
						</div>
					</div>
				<?php } ?>

			</div>
		</div>
	</div>
		<?php } ?>
</section>
<?php wp_reset_postdata(); ?>
<?php } ?>
