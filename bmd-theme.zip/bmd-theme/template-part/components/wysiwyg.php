<?php
$wysiwyg_content = get_sub_field( 'wysiwyg_content' );

if( $wysiwyg_content ){
    echo'<section class="wysiwyg-section">
        <div class="container">';
            echo $wysiwyg_content;
        echo '</div>
    </section>';
}

?>