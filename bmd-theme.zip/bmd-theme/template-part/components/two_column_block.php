<?php
$title =          get_sub_field('title');
$subtitle =       get_sub_field('subtitle');
$content =        get_sub_field('content');
$cta =            get_sub_field('cta');
$image =          get_sub_field('image');
$two_col_background_image = get_sub_field('two_col_background_image');
$image_position = get_sub_field('image_position');
$img = wp_get_attachment_image_url($image,'full');

if(!$img){
	$cls = ' cell-md-12 ';
}
else{
	$cls= ' justify-content-center ';
}
if($image || $title){
echo'
	<section class="two-col-block" style="background:url('. wp_get_attachment_image_url( $two_col_background_image, 'full' ).')center center; background-size: cover; background-repeat: no-repeat;">
	<div class="two-col-wrapper row no-gutters '.$image_position.$cls .'">';
		if($img){
			echo'<div class="left-col cell-md-6"><img src="'.$img.'"></div>';
		}
		if($title || $subtitle || $content){
			echo'
			<div class="right-col cell-md-6 '.$cls.'">
				<div class="inner-right-part">
					<div class="main-title">
						<div class="inner-content"><h2 class="h2">'.$title.'</h2></div>
					</div>
					<div class="subtitle">
						<div class="inner-content">'.$subtitle.'</div>
					</div>
					<div class="content">
						<div class="inner-content">'.$content.'</div>
					</div>';
						if($cta){
							$link_url    = $cta['url'];
							$link_title  = $cta['title'];
							$link_target = $cta['target'] ? $cta['target'] : '_self';

							echo'<div class="see-menu-btn"><a  class="btn" href="'. esc_url( $link_url ) .'" target="'. esc_attr( $link_target ).'">'. esc_html( $link_title ).'</a></div>';
						}
				echo'</div>
		</div>';
		}
echo '</div>
</section>';
}

?>
