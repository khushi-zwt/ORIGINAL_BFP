<?php
if( have_rows('page_component')) {
	$loop = 1;
    while ( have_rows('page_component') ) {
        the_row();
        $layout = get_row_layout();
        switch ( $layout ) {
            case "banner_block":
                include(locate_template('template-part/components/banner_block.php'));
            break;
			case "two_column_block":
                include(locate_template('template-part/components/two_column_block.php'));
            break;
			case "gallery_block":
                include(locate_template('template-part/components/gallery_block.php'));
            break;
			case "location_block":
                include(locate_template('template-part/components/location_block.php'));
            break;
			case "menu_block":
                include(locate_template('template-part/components/menu_block.php'));
            break;
			case "testimonial_block":
                include(locate_template('template-part/components/testimonial_block.php'));
            break;
			case "instagram_block":
                include(locate_template('template-part/components/instagram_block.php'));
            break;
			case "map_block":
                include(locate_template('template-part/components/map_block.php'));
            break;
			case "location_list_with_content":
                include(locate_template('template-part/components/location_list_with_content.php'));
            break;
        }
    }
}
?>
