<?php
/**
 * Template Name: Contact Page
 */

get_header();
// $hero_heading = get_field( 'hero_heading' );
// if( $hero_heading == '' ) {
// 	$hero_heading = get_the_title();
// }

echo '<!-- content area part -->';
echo '<div class="main-content">';
    include(locate_template('template-part/components.php'));
echo '</div>';

get_footer();
