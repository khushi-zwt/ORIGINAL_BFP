<?php
/**
 * The template for displaying 404 pages (not found)
 *
 */
if (!defined('ABSPATH') || !function_exists('add_filter')) {
	header('Status: 403 Forbidden');
	header('HTTP/1.1 403 Forbidden');
	exit;
}
get_header();

global $post;
$banner_image		= get_field('header_image', 'option');
echo'<section class="banner-section inner-banner-header">
	<div class="main-banner">
		<div class="banner-background-image" style="background:url('. $banner_image['url']. ') center center; background-size: cover; background-repeat: no-repeat;"></div>
		<div class="container">
			<div class="banner-inner">
				<div class="home-banner-text">
					<h1 class="h1">';
						echo '<span>'. _e( 'Oops! That page can&rsquo;t be found.') .'</span>';
					echo '</h1>
				</div>
			</div>
		</div>
	</div>
</section>';

echo '<div class="main-content">
	<section class="error-404" style="background:url('.get_template_directory_uri() .'/assets/images/bg_image.jpg) center center; background-size: cover; background-repeat: no-repeat;">
		<div class="container py-lg-90 py-50">	
			<p>The Page You Requested Cannot Be Found. The Page You Are Looking For Might Have Been Removed, Had Its Name Changed, Or Is Temporarily Unavailable.</p>
			</br>
			<h5>Please try the following:</h5>
			<ul>
				<li>If you typed the page address in the Address bar, make sure that it is spelled correctly.</li>';
				echo '<li>Open the <a href="'.get_home_url().'">Home Page</a> and look for links to the information you want..</li>';
				echo '<li>Use the navigation bar on the left or top to find the link you are looking for..</li>
			</ul>';
			echo '<a href="'.get_home_url().'" class="btn mt-15">Back To Home</a>';
	echo '</div>
	</section>
</div>';
get_footer();