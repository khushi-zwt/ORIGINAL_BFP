<?php
/**
* The template for displaying the footer
*/
?>

<!-- footer instagram part -->
<?php
$instagram_header    = get_field('instagram_title','option');
$instagram_shortcode = get_field('instagram_shortcode','option');

if(isset($instagram_shortcode) && !empty($instagram_shortcode)): ?>
	<section class="instagram-block"  style="background:url(<?php echo get_template_directory_uri() .'/assets/images/bg_image.jpg' ?>) center center; background-size: cover; background-repeat: no-repeat;">
		<div class="instagarm-block-wrapper">
			<?php if($instagram_shortcode) { ?>
				<div class="instagram-block-inner-wrapper">
					<div class="insta-header-wrapper row d-flex align-items-center">
						<div class="insta-header cell-md-9">
								<h2 class="h2"><?php echo $instagram_header; ?></h2>
						</div>
						<div class="main-social-icon-wrapper cell-md-3 d-flex justify-content-end">
							<?php if(have_rows( 'social_icons','option' )) { ?>
									<div class="social-media">
										<?php while( have_rows( 'social_icons','option' )) { the_row();
												$social_icon = get_sub_field( 'icon', 'option' );
												$social_link = get_sub_field('social_icon_link', 'option');

												if( $social_icon == 'instagram') { ?>
													<a href="<?php echo $social_link ?>" target="_blank"><img src="<?php echo  get_template_directory_uri().'/assets/images/instagram.svg';?>" alt="instagram" /></a><?php 
												}
												if( $social_icon == 'facebook') { ?>
													<a href="<?php echo $social_link ?>" target="_blank"><img src="<?php echo get_template_directory_uri().'/assets/images/facebook.svg'; ?>" alt="facebook" /></a><?php	
												}
											}
										?>
									</div>
							<?php } ?>
						</div>
					</div>
					<div class="instagram-slider"><?php echo do_shortcode( $instagram_shortcode );?></div>
				</div>
		<?php } ?>
		</div>
	</section>
<?php endif; ?>

<!-- footer map part -->
<?php
$map_title    = get_field('map_title','option');
$map_subtitle = get_field('map_subtitle','option');
$map_timings  = get_field('map_timings','option');
$map_desktop_image = get_field('map_desktop_image','option');
$map_mobile_image = get_field('map_mobile_image','option');

if(isset($map_mobile_image) && !empty($map_mobile_image)){
	$mb_map_img = $map_mobile_image['url'];
}else{
	$mb_map_img = $map_desktop_image['url'];
}


?>

<section class="map-wrapper" style="background:url(<?php echo $map_desktop_image['url']; ?>) center center; background-size: cover; background-repeat: no-repeat;">


	<div class="mobile-map-img-wrapper d-none">
		<img src="<?php echo $mb_map_img; ?>" alt="map">
	</div>
	
	<div class="container map-content">
		<div class="row map-block justify-content-end align-items-center">

			<div class="cell-md-6 inner-text-part">
				<div class="right-content-wrapper">

					<div class="map-meta-wrapper">
						<?php if($map_title): ?>
							<h2 class="h2"><?php echo $map_title; ?></h2>
						<?php endif; ?>
						<hr>
						<div class="map-inner-meta">
							<?php if($map_subtitle): ?>
								<h3 class="h3"><?php echo $map_subtitle; ?></h3>
							<?php endif; ?>

							<?php if($map_timings): ?>
								<p><?php echo $map_timings; ?></p>	
							<?php endif; ?>
						</div>
						<hr>
					</div>

					<div class="footer-locations-wrapper">

						<?php
						$location  = array( 
							'post_type' 	 => 'location',
							'orderby' 		 => 'post__in',
							'post_status'	 => 'publish',
							'posts_per_page' => -1,
						);
						$the_query = new WP_Query($location);
						if($the_query->have_posts()) { ?>
							<ul>
								<?php while($the_query->have_posts()) { $the_query->the_post();
									$phone 		= get_field('phone');
									$tel_phone 	= preg_replace( '/[^\d+]/', '', $phone ); ?>
										<li>
											<a href="<?php echo get_the_permalink(); ?>"><?php echo get_the_title(); ?></a>&nbsp;-&nbsp;
											<?php if($phone): ?><a href="tel:<?php echo $tel_phone; ?>"><?php echo $phone; ?> </a><?php endif; ?>
										</li>
								<?php } ?>
							</ul>

						<?php } ?>

					</div>
					<hr>

				</div>
			</div>
		</div>
	</div>
</section>


<?php 
// $footer_background_image = get_field('footer_background_image','option');
$copyright_footer 	= get_field('copyright_footer','option');
$footer_year     	= str_replace(" #Y# ", date('Y') , $copyright_footer);
$menu_icon 			= get_field('menu_icon','option');
$footer_logo 		= get_field('footer_logo','option');
$footer_menu 		= array(
	'theme_location'  => 'footer_menu',
	'container'       => 'ul',
	'container_class' => 'footer_menu',
);

echo '</div>
<!-- footer part -->
	<footer class="main-footer py-30" style="background:url('. get_template_directory_uri(). '/assets/images/footer-bg.jpg) center center; background-size: cover; background-repeat: no-repeat;">
		<div class="footer-wrap d-flex">';
			if($footer_menu || $footer_logo || $copyright_footer){
				if($footer_logo){
					echo'<div class="left-wrapper d-flex align-items-center">
							<div class="main-social-icon-wrapper">';
								if(have_rows( 'social_icons','option' )) {
									echo '<div class="social-media">' ;
										while( have_rows( 'social_icons','option' )) {
											the_row();
											$social_icon = get_sub_field( 'icon', 'option' );
											$social_link = get_sub_field('social_icon_link', 'option');
					
											if( $social_icon == 'instagram') {
												echo '<a href="' . $social_link . '" target="_blank"><img src="' . get_template_directory_uri() . '/assets/images/instagram.svg" alt="instagram" /></a>' ;
											}
											if( $social_icon == 'facebook') {
												echo '<a href="' . $social_link . '" target="_blank"><img src="' . get_template_directory_uri() . '/assets/images/facebook.svg" alt="facebook" /></a>' ;
											}
										}
									echo '</div>';
								}
							echo'</div>';
							if(has_nav_menu('footer_menu')){
								echo'<div class="navigation">'. wp_nav_menu($footer_menu ) .'</div>';
							}
					echo'</div>
					<div class="middle-wrapper">
						<div class="footer-logo">
							<a href="'.home_url( '/' ).'" class="brand"><img src="'.$footer_logo['url'].'" alt="'.get_bloginfo('name').'"></a>
						</div>
					</div>
					<div class="right-wrapper d-flex align-items-center">
						<div class="contact-part">'.$footer_year.'</div>
						<div class="footer-right-img hamburger"><img src="'.get_template_directory_uri().'/assets/images/header-menu-icon.svg" alt="menu-icon"></div>
					</div>';
				}
			}
		echo'</div>
		<a class="studio" href="https://patrickcarterdesign.com/">Logo Design, Branding, Website Design and Development by 63 Visual Design Studio in Jacksonville Beach, Florida.</a>
	</footer>
</div>';
wp_footer();
echo '</body>
</html>';
