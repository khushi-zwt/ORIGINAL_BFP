<?php
$main_top_title         = get_field('main_top_title');
$case_study_description = get_field('case_study_description');
$case_study_post        = get_field('case_study_post');
$case_study_description = get_field('case_study_description');
$load_more_hideshow     = get_field('load_more_hideshow');
$load_more              = get_field('load_more');
?>


<?php
wp_reset_query();
$paged = ( get_query_var('paged') ) ? get_query_var('paged') : 1;
?>
<?php
$args = [
    "post_type"      => "case-study",
    "post_status"    => "publish",
	"posts_per_page" =>  3,
	"order"          => 'ASC',
];
$the_query = new WP_Query($args);
?>


<?php if($the_query->have_posts()) { 
	$post_count  = $the_query->post_count;
	$found_posts = $the_query->found_posts; ?>
	<div class="case-studies-section">
		<div class="container">

		<input id="cs_paged" type="hidden" value="<?php echo $paged; ?>" name="cs_paged">
		<input id="cs_paged_name_for_ajax" type="hidden" value="case-study" name="cs_paged_name">

			<div class="titles-block">
				<?php if( !empty( $main_top_title ) ) { ?>
					<h2 class="h1 text-center"><?php echo $main_top_title ; ?></h2>
				<?php } ?>
				<?php if( !empty( $case_study_description ) ) {
					echo $case_study_description ;
				} ?>
			</div>

			<div class="case-studies-slider" id="cs_load_more_holder">
			<?php while($the_query->have_posts()) { $the_query->the_post();
					// $featured_image_url = get_the_post_thumbnail_url( $case_study->ID ) ;
					$featured_image_src = get_the_post_thumbnail($case_study->ID);
					$case_study_title   = get_the_title($case_study->ID) ;
					$case_study_content = wp_trim_words( get_the_content(), 20, '' ); ?>
					<?php if( !empty( $case_study_title || $case_study_content ) ) { ?>
					<div class="block">
						<div class="card-wrapper">
						<?php if( !empty( $featured_image_src ) ) { ?>
								<div class="post-image">
									<a class="study-image-parent"  href="<?php the_permalink( $case_study->ID ) ; ?>">
										<?php echo $featured_image_src; ?>
									</a>
								</div>
						<?php } ?>
							<div class="case-study-content">
								<div class="content-left">
								<?php if( !empty( $case_study_title ) ) { ?>
									<a href="<?php the_permalink( $case_study->ID ) ; ?>" class="h4"><?php echo $case_study_title; ?></a>
								<?php } ?>
								<?php if( !empty(  $case_study_content ) ) {
										echo $case_study_content; 
								} ?>
								</div>
								<div class="content-right">
									<a href="<?php the_permalink( $case_study->ID ) ; ?>" class="btn-view"><i class="icon-plus"></i><?php echo __( 'View', 'mercuryconveyors' ) ?></a>
								</div>
							</div>
						</div>
					</div>
				<?php } } wp_reset_postdata(); ?>
			</div>

			<?php if( !empty($load_more) ) {
				$load_more_title = $load_more['title']; ?>
					<?php if($load_more_hideshow) { 
						if($found_posts > 1){ ?>
						<div class="cs-post-btn" id="cs-post-btn">
							<a class="btn" id="cs_load_more_btn" href="javascript:void(0);" data-paged="<?php echo $paged; ?>" ><?php echo esc_html( $load_more_title ); ?></a>
						</div>
					<?php } }?>
			<?php } ?>
		</div>
	</div>
<?php } ?>
