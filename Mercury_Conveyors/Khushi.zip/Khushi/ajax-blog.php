<?php
/**
 * Blog [Load more] Ajax Function
 */

// add_action( 'wp_ajax_blog_load_more', 'blog_load_more' );
// add_action( 'wp_ajax_nopriv_blog_load_more', 'blog_load_more' );
// function blog_load_more(){
// 	print_r($_POST);
// 	exit();	
// }
?>
<?php
/**
 * Review [Load more] Ajax Function
 */
function blog_load_more(){
    
    check_ajax_referer( 'blog-load-more-nonce', 'security' );

    $html			= '';

    $post_per_page	= $_POST['posts_per_page'];
    $paged			= $_POST['paged'];

    $paged		    = $paged+1;

    $args = array(
        'post_type'         => 'post',
        'order' 		    => 'DESC',
        'orderby' 	        => 'date',
        'posts_per_page'	=> $post_per_page,
        'paged'				=> $paged,
    );

	// echo '<pre>';
	// print_r( $post_per_page );
	// echo '</pre>';
	
    $query = new WP_Query( $args );

    if ( $query->have_posts() ) {
        $post_count = $query->post_count;
        $found_posts = $query->found_posts;

        $loop = 1;
        while ( $query->have_posts() ) { $query->the_post();
            $title      = get_the_title();
            $content    = get_the_content();
            // $star_rating= get_field('star_rating');
            
            if($loop == $post_count){
                if($found_posts > ($post_count*$paged)){
                    if($loop == $post_per_page){
                        $do_load_more = true;
                    }
                }
            }

            // $html_rating='';
            // $html_rating.='
            // <div class="ratting">';
            //     for($i=0; $i < $star_rating; $i++) {
            //         $html_rating.='<i class="icon icon-star"></i>';
            //     }
            // $html_rating.='
            // </div>';
            
            $do_load_more_html='';
            if($do_load_more){
                $do_load_more_html = '
                <li class="load-more-cell">
                    <div class="load-more-btn d-flex justify-content-center align-items-center">
                        <a class="btn btn-black" id="blog_load_more_btn" href="javascript:void(0)" data-paged="'.$paged.'">Load More</a>
                    </div>
                </li>
                ';
            }

            $html.='
            <li>
                '.$html_rating.'
                <div class="reviews-content">
                    '.$content.'
                </div>
                <div class="reviews-title" href="javascript:void(0)">
                    '.$title.'
                </div>
            </li>'
            .$do_load_more_html;
            $loop++;
        }wp_reset_postdata();
    }

    $data['posts'] 		= $html;

    if(!empty($html)){
		$msg = array('response'=>'success', 'data' => $data);
		echo json_encode($msg);
		exit();
	}else{
		$html = '<div class="cell-12 mt-30">
                    <div class="mt-30 text-center">
					    <h4>No more Reviews found!</h4>
                    </div>
                </div>';
		$data['posts']	= $html;

		$msg = array('response'=>'error', 'data' => $data, 'message'=>'Error in response');
		echo json_encode($msg);
		exit();
	}

	wp_die();
}

add_action( 'wp_ajax_blog_load_more', 'blog_load_more' );
add_action( 'wp_ajax_nopriv_blog_load_more', 'blog_load_more' );
